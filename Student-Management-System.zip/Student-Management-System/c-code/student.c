#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DATA_FILE "data/students.txt"
#define TEMP_FILE "data/temp.txt"

struct Student {
    int id;
    char name[50];
    float marks;
};

void addStudent(int id, char name[], float marks) {
    FILE *fp = fopen(DATA_FILE, "a");

    if (fp == NULL) {
        printf("File Error\n");
        return;
    }

    fprintf(fp, "%d %s %.6f\n", id, name, marks);
    fclose(fp);

    printf("Student Added Successfully\n");
}

void viewStudents() {
    FILE *fp = fopen(DATA_FILE, "r");

    if (fp == NULL) {
        printf("File Error\n");
        return;
    }

    struct Student s;
    int found = 0;

    while (fscanf(fp, "%d %49s %f", &s.id, s.name, &s.marks) == 3) {
        printf("%d %s %.2f\n", s.id, s.name, s.marks);
        found = 1;
    }

    if (!found) {
        printf("No students found.\n");
    }

    fclose(fp);
}

void searchStudent(int id) {
    FILE *fp = fopen(DATA_FILE, "r");

    if (fp == NULL) {
        printf("File Error\n");
        return;
    }

    struct Student s;
    int found = 0;

    while (fscanf(fp, "%d %49s %f", &s.id, s.name, &s.marks) == 3) {
        if (s.id == id) {
            printf("Found: %d %s %.2f\n", s.id, s.name, s.marks);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("Student Not Found\n");
    }

    fclose(fp);
}

void deleteStudent(int id) {
    FILE *fp = fopen(DATA_FILE, "r");
    FILE *temp = fopen(TEMP_FILE, "w");

    if (fp == NULL || temp == NULL) {
        printf("File Error\n");
        if (fp != NULL) {
            fclose(fp);
        }
        if (temp != NULL) {
            fclose(temp);
        }
        return;
    }

    struct Student s;
    int deleted = 0;

    while (fscanf(fp, "%d %49s %f", &s.id, s.name, &s.marks) == 3) {
        if (s.id == id) {
            deleted = 1;
        } else {
            fprintf(temp, "%d %s %.6f\n", s.id, s.name, s.marks);
        }
    }

    fclose(fp);
    fclose(temp);

    remove(DATA_FILE);
    rename(TEMP_FILE, DATA_FILE);

    printf(deleted ? "Deleted Successfully\n" : "Student Not Found\n");
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Invalid Arguments\n");
        return 1;
    }

    if (strcmp(argv[1], "add") == 0) {
        if (argc < 5) {
            printf("Invalid Arguments\n");
            return 1;
        }
        addStudent(atoi(argv[2]), argv[3], (float)atof(argv[4]));
    } else if (strcmp(argv[1], "view") == 0) {
        viewStudents();
    } else if (strcmp(argv[1], "search") == 0) {
        if (argc < 3) {
            printf("Invalid Arguments\n");
            return 1;
        }
        searchStudent(atoi(argv[2]));
    } else if (strcmp(argv[1], "delete") == 0) {
        if (argc < 3) {
            printf("Invalid Arguments\n");
            return 1;
        }
        deleteStudent(atoi(argv[2]));
    } else {
        printf("Invalid Command\n");
        return 1;
    }

    return 0;
}
