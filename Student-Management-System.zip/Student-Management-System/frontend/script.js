const BASE_URL = window.location.origin.startsWith("http")
    ? window.location.origin
    : "http://localhost:3000";

const output = document.getElementById("output");

function setOutput(message) {
    output.innerText = message;
}

async function requestText(url, options) {
    const response = await fetch(url, options);
    const text = await response.text();

    if (!response.ok) {
        throw new Error(text || "Request failed");
    }

    return text;
}

function getRequiredValue(id, label) {
    const value = document.getElementById(id).value.trim();

    if (!value) {
        throw new Error(`Please enter ${label}.`);
    }

    return value;
}

async function addStudent() {
    try {
        const id = getRequiredValue("id", "ID");
        const name = getRequiredValue("name", "name");
        const marks = getRequiredValue("marks", "marks");

        const message = await requestText(`${BASE_URL}/add`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id, name, marks })
        });

        setOutput(message);
        document.getElementById("id").value = "";
        document.getElementById("name").value = "";
        document.getElementById("marks").value = "";
        await viewStudents();
    } catch (error) {
        setOutput(error.message);
    }
}

async function viewStudents() {
    try {
        const data = await requestText(`${BASE_URL}/view`);
        setOutput(data);
    } catch (error) {
        setOutput(error.message);
    }
}

async function searchStudent() {
    try {
        const id = getRequiredValue("searchId", "student ID");
        const data = await requestText(`${BASE_URL}/search/${encodeURIComponent(id)}`);
        setOutput(data);
    } catch (error) {
        setOutput(error.message);
    }
}

async function deleteStudent() {
    try {
        const id = getRequiredValue("deleteId", "student ID");
        const message = await requestText(`${BASE_URL}/delete/${encodeURIComponent(id)}`, {
            method: "DELETE"
        });

        document.getElementById("deleteId").value = "";
        setOutput(message);
        await viewStudents();
    } catch (error) {
        setOutput(error.message);
    }
}
