const express = require("express");
const cors = require("cors");
const { execFile } = require("child_process");
const fs = require("fs/promises");
const path = require("path");

const app = express();
const PORT = 3000;
const DATA_DIR = path.join(__dirname, "data");
const STUDENTS_FILE = path.join(DATA_DIR, "students.txt");
const TEMP_FILE = path.join(DATA_DIR, "temp.txt");
const FRONTEND_DIR = path.join(__dirname, "..", "frontend");
const STUDENT_EXE = path.join(__dirname, "..", "c-code", "student.exe");

app.use(cors());
app.use(express.json());
app.use(express.static(FRONTEND_DIR));

async function ensureDataFile() {
    await fs.mkdir(DATA_DIR, { recursive: true });

    try {
        await fs.access(STUDENTS_FILE);
    } catch {
        await fs.writeFile(STUDENTS_FILE, "", "utf8");
    }
}

function validateId(idValue) {
    const id = Number(idValue);

    if (!Number.isInteger(id) || id <= 0) {
        return { error: "Please enter a valid positive student ID." };
    }

    return { id: String(id) };
}

function validateStudent(input) {
    const { id, error } = validateId(input.id);
    const name = String(input.name || "").trim();
    const marks = Number(input.marks);

    if (error) {
        return { error };
    }

    if (!/^[A-Za-z0-9_-]+$/.test(name)) {
        return { error: "Name me space ya special character mat use karo. Example: Aarav_Chauhan" };
    }

    if (!Number.isFinite(marks) || marks < 0 || marks > 100) {
        return { error: "Please enter marks between 0 and 100." };
    }

    return { student: { id, name, marks: String(marks) } };
}

async function runStudentProgram(args) {
    await ensureDataFile();

    return new Promise((resolve, reject) => {
        execFile(STUDENT_EXE, args, { cwd: __dirname, timeout: 5000 }, (error, stdout, stderr) => {
            if (error) {
                const message = stderr || stdout || error.message;
                reject(new Error(message.trim()));
                return;
            }

            resolve(stdout.trim());
        });
    });
}

async function finishDeleteFromTemp(output) {
    if (!output.includes("Deleted Successfully")) {
        return;
    }

    try {
        await fs.access(TEMP_FILE);
        await fs.copyFile(TEMP_FILE, STUDENTS_FILE);
        await fs.writeFile(TEMP_FILE, "", "utf8");
    } catch {
        // Newer C builds rename temp themselves, so no temp file is also fine.
    }
}

app.post("/add", async (req, res) => {
    try {
        const { student, error } = validateStudent(req.body);
        if (error) {
            return res.status(400).send(error);
        }

        const output = await runStudentProgram(["add", student.id, student.name, student.marks]);
        res.send(output || "Student Added Successfully");
    } catch (error) {
        console.error(error);
        res.status(500).send(error.message || "Server error while adding student.");
    }
});

app.get("/view", async (req, res) => {
    try {
        const output = await runStudentProgram(["view"]);
        res.type("text/plain").send(output || "No students found.");
    } catch (error) {
        console.error(error);
        res.status(500).send(error.message || "Server error while reading students.");
    }
});

app.get("/search/:id", async (req, res) => {
    try {
        const { id, error } = validateId(req.params.id);
        if (error) {
            return res.status(400).send(error);
        }

        const output = await runStudentProgram(["search", id]);
        res.send(output || "Student Not Found");
    } catch (error) {
        console.error(error);
        res.status(500).send(error.message || "Server error while searching student.");
    }
});

app.delete("/delete/:id", async (req, res) => {
    try {
        const { id, error } = validateId(req.params.id);
        if (error) {
            return res.status(400).send(error);
        }

        const output = await runStudentProgram(["delete", id]);
        await finishDeleteFromTemp(output);
        res.send(output || "Deleted Successfully");
    } catch (error) {
        console.error(error);
        res.status(500).send(error.message || "Server error while deleting student.");
    }
});

app.use((req, res) => {
    res.sendFile(path.join(FRONTEND_DIR, "index.html"));
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
